pdflatex livrerecettes.tex
pdflatex livrerecettes.tex
makeindex -s nom.ist nom.idx
makeindex -s cat.ist cat.idx
pdflatex livrerecettes.tex
