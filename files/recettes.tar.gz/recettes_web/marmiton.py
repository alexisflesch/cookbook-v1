#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib, sys
import pygtk
pygtk.require('2.0')
import gtk


def recup_page(url):
    f = urllib.urlopen(url)
    a = f.read()
    f.close()
    return a


def transforme(a):
    recette = a.split('<span class="stdtxt10">')[1].split("</span>")[0]
    titre = a.split("title='Envoyer la recette : ")[1].split(" à un(e) ami.'>")[0]
    tps_preparation = recette.split("Ingrédients")[0].split("<br>")[0].split("Préparation")[1][3:].replace("min","minutes")
    tps_cuisson = recette.split("Ingrédients")[0].split("<br>")[1][10:].replace("min","minutes")
    nb_personnes = recette.split("Ingrédients")[1].split(":")[0][2:-2]
    liste_ingredients = recette.split("Ingrédients")[1].split(":")[1].split("Préparation")[0].replace("<br>-","\n\\item").replace("oeuf","\\oe uf")
    preparation = recette.split("Ingrédients")[1].split("Préparation :")[1].replace("<br>","").replace("oeuf","\\oe uf")

    finish = "\\begin{nouvellerecette}\n"
    finish += "\\recette{" + titre + "}\n"
    finish += "\n"
    finish += "\\index{nom}{}\n"
    finish += "\\index{cat}{}\n"
    finish += "\n"
    finish += "\\temps{" + tps_preparation + "}{" + tps_cuisson + "}\n"
    finish += "\n"
    finish += "\\ingredients[" + nb_personnes +"]{"
    finish += liste_ingredients.replace("<br>","")
    finish += "\n}"
    finish += "\n\n"
    finish += preparation.replace("°","\\degrees")
    finish += "\n\n"
    finish += "\\end{nouvellerecette}"
    
    return finish


a = transforme(recup_page(sys.argv[1]))
clipboard = gtk.clipboard_get()
clipboard.set_text(a)
clipboard.store()
